<?php 
 $server = "localhost";
 $user = "root";
 $password = "";
 $database = "php_crud_image";

 mysqli_connect($server, $user, $password, $database) OR DIE ("Koneksi Gagal");

?>